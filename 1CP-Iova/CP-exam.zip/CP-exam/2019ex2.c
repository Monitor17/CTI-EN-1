#include<stdio.h>
#include<stdint.h>
unsigned swap_nibbles(unsigned n)
{
  unsigned most_significant_nibble=n>>28;
  unsigned least_significant_nibble=n<<28;
  n=n<<4;
  n=n>>4;
  n=least_significant_nibble|n;
  n=n>>4;
  n=n<<4;
  n=most_significant_nibble|n;
  return n;
}
int main()
{
  printf("%x",swap_nibbles(0x1A2B3C4D));
  return 0;
}
