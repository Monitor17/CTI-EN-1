/*3. (10 points) Implement a C function that will find, search and replace text strings. Receives three strings (s1, s2 and s3) and
replaces all the occurrences of string s2 into the first string (s1), with the third string (s3), returning the new string. The
replacement phrase can be shorter or longer than the searched for phrase. Show the updated initial line of text on the display.*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int appearences_of_the_word(char* s1, const char* s2){
    int count=0;
    char* s4;
    s4=strdup(s1);
    char* p=strtok(s4," ");
    while(p)
    {
        int same_elem=0;
        for(int i=0;i<strlen(s2);i++)
        {
            if(p[i]==s2[i])
            {
                same_elem++;
            }
        }
        if(same_elem==strlen(s2))
        {
            count++;
        }
        p=strtok(NULL," ");
    }
    return count;
}
char* new_string(char* s1, const char* s2, const char* s3)
{
    char* result=NULL;
    result=(char*)malloc(strlen(s1)+(strlen(s3)-strlen(s2))*appearences_of_the_word(s1,s2));
    if(result==NULL)
    {
        return NULL;
    }
    unsigned i=0,j=0;
    while(s1[i])
    {
        if(strncmp(s1+i,s2,strlen(s2))==0)
        {
            strncpy(result+j,s3,strlen(s3));
            j+=strlen(s3);
            i+=strlen(s2);
        }
        else 
        {
            result[j]=s1[i];
            i++;
            j++;
        }
    }
    result[j]='\0';f
    return result;
}
int main()
{
    char s1[] = "appleappleapple";
    char s2[] = "apple";
    char s3[] = "orange";
    char* result;
    result=new_string(s1,s2,s3);
    printf("%s",result);
    free(result);
    return 0;
}