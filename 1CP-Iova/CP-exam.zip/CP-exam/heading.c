/*Write a function that prints in alphabetical order all headings from an HTML file named on the command line.
A heading is enclosed between tags <hN> and </hN> with N a digit from 1 to 6. Headings are at most 100 chars long, but
arbitrarily many.
I.e.: a possible input is <h2>Upt</h2> <h3>Acsa</h3> which would print Acsa Upt*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int compareHeading(const void *a, const void *b)
{
    return strcmp(*(char **)a, *(char **)b);
}
void printHeadings(FILE *inputFile)
{
    char line[109];
    char *headings[100];
    int heading_count = 0;
    while (fscanf(inputFile, "%s", line) == 1)
    {
        headings[heading_count] = strdup(line);
        heading_count++;
    }
    for (int i = 0; i < heading_count; i++)
    {
        for (int j = 0; j < strlen(headings[i]); j++)
        {
            headings[i][j] = headings[i][j + 4];
        }
        headings[i][strlen(headings[i]) - 5] = '\0';
    }
    fclose(inputFile);
    qsort(headings, heading_count, sizeof(char *), compareHeading);
    for (int i = 0; i < heading_count; i++)
    {
        printf("%s ", headings[i]);
    }
}
int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Please introduce the input file :)");
        return -1;
    }
    FILE *inputFile = fopen(argv[1], "r");
    if (inputFile == NULL)
    {
        printf("Please introduce the input file :)");
        return -1;
    }
    printHeadings(inputFile);
}