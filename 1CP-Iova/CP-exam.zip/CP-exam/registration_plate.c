/*Write a program that prints in order of the numerical values all the registration plates belonging to cars registred
in a particular county, from a list found in a file with it’s path read from standard input.
Consider the common Romanian registration plate of the format: County-Number-Id (I.e. TM-01-ABC) (the Number part
might be represented on two or three digits). Break ties by the lexicographical values of the Id. Normalize all the values to
uppercase. Skip all the records which don’t match the pattern.*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAX_PLATE_LENGTH 20
void normalizePlate(char s[]){
    for(size_t i=0;i<strlen(s);i++){
        if(s[i]>='a' && s[i]<='z')
        {
            s[i]=s[i]-('a'-'A');
        }
    }
}
int comparePlates(const void* a,const void* b){
    char id1[4],id2[4];
    char county1[3],county2[3];
    int plateNumber1,plateNumber2;
    sscanf(*(const char**)a,"%1s-%3d-%3s",county1,&plateNumber1,id1);
    sscanf(*(const char**)a,"%2s-%3d-%3s",county1,&plateNumber1,id1);
    sscanf(*(const char**)b,"%1s-%3d-%3s",county2,&plateNumber2,id2);
    sscanf(*(const char**)b,"%2s-%3d-%3s",county2,&plateNumber2,id2);
    if(plateNumber1!=plateNumber2){
        return plateNumber1-plateNumber2;
    }
    if(strcmp(id1,id2)){
        return strcmp(id1,id2);
    }
    return strcmp(county1,county2);
}
int main(){
    char filePath[100];
    printf("Enter file path: ");
    scanf("%s",filePath);
    FILE* inputFile=fopen(filePath,"r");
    if(inputFile==NULL)
    {
        printf("Please create the input file!");
        return -1;
    }
    char s[MAX_PLATE_LENGTH];
    char* plates[MAX_PLATE_LENGTH];
    size_t countPlates=0;
    char county[3];
    int number;
    char id[4];
    while(fscanf(inputFile,"%s",s)==1)
    {
        if(sscanf(s,"%2s-%3d-%3s",county,&number,id)==3 || sscanf(s,"%1s-%3d-%3s",county,&number,id)==3)
        {
            plates[countPlates]=strdup(s);
            countPlates++;
        }
    }
    fclose(inputFile);
    for(size_t i=0;i<countPlates;i++)
    {
        normalizePlate(plates[i]);
    }
    qsort(plates,countPlates,sizeof(char*),comparePlates);
    for(size_t i=0;i<countPlates;i++)
    {
        printf("%s\n",plates[i]);
    }
}