/*Write a function that reads a file named on the command line and 
prints all words in increasing length order, breaking ties alphabetically. 
Words are strings of non-whitespace characters. You may truncate any words 
longer than 63 chars. The file is arbitrarily large. Be efficient!*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX_WORD_LENGTH 63
int mystrlen(const char* s)
{
    int i=0;
    while(s[i])
    {
        i++;
    }
    return i;
}
int mystrcmp(const char* s1,const char* s2)
{
    int i=0;
    int stop=0;
    int difference;
    while((s1[i]!=0 || s2[i]!=0) && stop==0)
    {
        difference=s1[i]-s2[i];
        if(s1[i]-s2[i]!=0)
        {
            stop=1;
        }
        i++;
    }
    return difference;
}
int compareWords(const void* a, const void* b){
    const char* word1=*(const char**)a;
    const char* word2=*(const char**)b;
    int length1=mystrlen(word1);
    int length2=mystrlen(word2);
    if(length1!=length2){
        return length1-length2;
    }
    return mystrcmp(word1,word2);
}
void printWords(FILE* input)
{
    char *string_of_words[MAX_WORD_LENGTH+1]={0};
    char word[MAX_WORD_LENGTH+1]={0};
    int i=0;
    while(fscanf(input,"%63s",word)==1)
    {
        string_of_words[i]=strdup(word);
        i++;
    }
    qsort(string_of_words,i,sizeof(char*),compareWords);
    for(int j=0;j<i;j++)
    {
        printf("%s %d\n",string_of_words[j],mystrlen(string_of_words[j]));
    }
}
int main(int argc, char* argv[])
{
    if(argc<2)
    {
        return -1;
    }
    FILE* inputFile=fopen(argv[1],"r");
    if(inputFile==NULL)
    {
        printf("Enter the file path!");
        return -1;
    }
    else{
    printWords(inputFile);}
    return 0;
}