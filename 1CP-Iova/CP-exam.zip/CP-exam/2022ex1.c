#include<stdio.h>
#include<ctype.h>
int parantheses()
{
  int c=getchar();
  int currentValue=0;
  int sum=0;
  while(c!=')')
    {
      if(c>='0' && c<='9')
	{
	  while(c>='0' && c<='9')
	    {
	      currentValue=currentValue*10+c-'0';
	      c=getchar();
	    }
	  continue;
	}
      else
	{
	  sum=sum+currentValue;
	  currentValue=0;
	}
      c=getchar();
    }
  sum=sum+currentValue;
  return sum;
}
int function()
{
  int c=getchar();
  int currentValue=0;
  int product=1;
  while(c!=EOF && c!='\n')
    {
      if(c>='0' && c<='9')
	{
	  currentValue=0;
	  while(c>='0' && c<'9')
	    {
	      currentValue=currentValue*10+c-'0';
	      c=getchar();
	    }
	  continue;
	}
      else if(c=='(')
	{
	   product=product*currentValue;
	  currentValue=parantheses();
	}
      else
	{
	  product=product*currentValue;
	   currentValue=1;
	}
      c=getchar();
    }
  product=product*currentValue;
  return product;
}
int main()
{
  int result=function();
  printf("%d",result);
  return 0;
}
  
	  
	       
