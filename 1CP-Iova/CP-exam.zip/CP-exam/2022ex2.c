#include<stdio.h>
#include<stdint.h>
uint64_t new_number(unsigned n)
{
  uint64_t result=0;
  while(n!=0)
    {
      int uc=n%10;
      for(int i=0;i<uc;i++)
	{
	  if(uc%2==0)
	    {
	      result=result<<1|1;
	      printf("1");
	    }
	  else
	    {
	      result=result<<1;
	      printf("0");
	    }
	}
      n=n/10;
    }
  return result;
}
int main()
{
  int n=1234;
  printf("\n%llu",new_number(n));
  return 0;
}
	      
