/* Implement a C program that checks whether an HTML file with path read from standard input (path less than
100 caracthers) has all tables correct (all rows in a table have equal column counts). A table is enclosed between tags
<table> and </table>. A table row is enclosed between tags <tr> and </tr> and a table cell between </td> and </td>.
Whitespace between tags does not matter.*/
#include<stdio.h>
#include<string.h>
#define MAX_LEN 100
void check_tables()
{
    int insideTable=0;
    int insideRow=0;
    int insideDataCell=0;
    int insideHeader=0;
    int ok=-1;
    char word[1000];
    FILE* file=fopen("text.html","r");
    if(file==NULL)
    {
        return ;
    }
    while(fscanf(file,"%99s",word)==1){
        if(strstr(word,"<table")){
            if(insideTable==0){
                insideTable=1;
            }
            else{
               ok=0;
            }
        }
        if(strstr(word,"<tr")){
            if(insideRow==0){
                insideRow=1;
            }
            else{
                ok=0;
            }
        }
        if(strstr(word,"<td")){
            if(insideDataCell==0){
                insideDataCell=1;
            }
            else{
                ok=0;
            }
        }
        if(strstr(word,"<th")){
            if(insideHeader==0){
                insideHeader=1;
            }
            else{
                ok=0;
            }
        }
        if(strstr(word,"</table")){
            if(insideTable==1){
                insideTable=0;
            }
            else{
                ok=0;
            }
        }
        if(strstr(word,"</tr")){
            if(insideRow==1){
                insideRow=0;
            }
            else{
                ok=0;
            }
        }
        if(strstr(word,"</th")){
            if(insideHeader==1){
                insideHeader=0;
            }
            else{
                ok=0;
            }
        }
        if(strstr(word,"</td")){
            if(insideDataCell==1){
                insideDataCell=0;
            }
            else{
                ok=0;
            }
        }
    }
    if(ok!=0){
        printf("OK");
    }
    else{
        printf("NO");
    }
}
int main(){
    check_tables();
    return 0;
}