f#include<stdio.h>
#include<ctype.h>
int prime_number(int n)
{
  int divisors=0;
  if(n==2)
    {
      return 1;
    }
  else
    {
      for(int d=2;d<n;d++)
	{
	  if(n%d==0)
	    {
	      divisors++;
	    }
	}
      if(0==divisors)
	{
	  return 1;
	}
      else
	{
	  return 0;
	}
    }
}
int function(int c)
{
  int currentValue=0;
  int length_of_prime_numbers=0;
  int maximum_length=0;
  while(c!=EOF)
    {
      if(c>='0' && c<='9')
	{
	  currentValue=currentValue*10+c-'0';
	}
      else if(','==c)
	{
	  if(prime_number(currentValue))
	    {
	      length_of_prime_numbers++;
	    }
	  else
	    {
	      if(length_of_prime_numbers>maximum_length)
		{
		  maximum_length=length_of_prime_numbers;
		}
	      length_of_prime_numbers=0;
	    }
	}
      c=getchar();
    }
  if(prime_number(currentValue))
    {
      length_of_prime_numbers++;
      if(length_of_prime_numbers>maximum_length)
	{
	  maximum_length=length_of_prime_numbers;
      	}
    }
  if(0==maximum_length)
    {
      return -1;
    }
  else
    {
      return maximum_length;
    }
}
int main()
{
  int c=getchar();
  printf("%d",function(c));
  return 0;
}
