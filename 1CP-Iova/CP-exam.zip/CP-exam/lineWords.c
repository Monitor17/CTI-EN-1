/*Write a function to read a text over several lines until end of file and then print only
those lines containing a ”word” (string made of only non-whitespace characthers), received as parameter.
Note that you have to write your own string processing functions*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int mystrlen(const char *s)
{
    int i = 0;
    while (s[i])
    {
        i++;
    }
    return i;
}
int mystrcmp(char *s1, const char *s2)
{
    int i = 0;
    int stop = 0;
    int difference;
    while ((s1[i] != 0 || s2[i] != 0) && stop == 0)
    {
        difference = s1[i] - s2[i];
        if (s1[i] - s2[i] != 0)
        {
            stop = 1;
        }
        i++;
    }
    return difference;
}
void word_on_line(char *s)
{
    FILE *input = fopen("inputfile.txt", "r");
    if (input == NULL)
    {
        return;
    }
    char c;
    char word[10000];
    int i = 0;
    char line[10000];
    int ok = 0;
    int characters_on_line = 0;
    while ((c = fgetc(input)) != EOF)
    {
        if (isalpha(c))
        {
            word[i] = c;
            i++;
        }
        else
        {
            if (mystrcmp(word, s) == 0)
            {
                ok = 1;
            }
            for (int j = 0; j < i; j++)
            {
                word[j] = '\0';
            }
            i = 0;
        }
        if (c != '\n')
        {
            line[characters_on_line] = c;
            characters_on_line++;
        }
        else
        {
            if (ok == 1)
            {
                printf("%s\n", line);
                ok = 0;
            }
            for (int k = 0; k < characters_on_line; k++)
            {
                line[k] = '\0';
            }
            characters_on_line = 0;
        }
    }
}
int main()
{
    char s[] = "example";
    word_on_line(s);
    return 0;
}