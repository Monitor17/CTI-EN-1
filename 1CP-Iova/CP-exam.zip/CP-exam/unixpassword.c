/*Implement a function that receives as argument a C-string representing a file path to a Unix password file (with
the structure described below) and prints the list of unix-groups in descending number of users assigned to those groups. The
Unix password file structure is as follows: Username:X:UserId:GroupId:EXTRA FIELDS
where you are to use the GroupId to identify the group to which each UserName is assigned. You might assume a
program-level defined maximum number of rows in the file.*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXIMUM_LINES 200
typedef struct
{
    char string[200];
    int count;
} StringCount;
int sortStringsApp(const void *a, const void *b)
{
    const char *groupID1 = *(const char **)a;
    const char *groupID2 = *(const char **)b;
    return strcmp(groupID1, groupID2);
}
int sortGroups(const void* a,const void* b){
    if(((StringCount*)a)->count-((StringCount*)b)->count!=0){
    return ((StringCount*)b)->count-((StringCount*)a)->count;
    }
    else{
        return strcmp(((StringCount*)a)->string,((StringCount*)b)->string);
    }
}
int main()
{
    FILE *inputFile = fopen("unixpasswords.txt", "r");
    if (inputFile == NULL)
    {
        printf("Please enter the input file!");
        return -1;
    }
    char s[1000000];
    char username[70];
    char userID[70];
    char group_ID[70];
    char *IDs[70];
    char EXTRA_FIELDS[70];
    int number_of_users = 0;
    while (fscanf(inputFile, "%s", s) == 1)
    {
        if (sscanf(s, "%[^:]:x:%[^:]:%[^:]:%[^:]", username, userID, group_ID, EXTRA_FIELDS) == 4)
        {
            IDs[number_of_users] = strdup(group_ID);
            number_of_users++;
        }
    }
    if (number_of_users!=0)
    {
        qsort(IDs, number_of_users, sizeof(IDs[0]), sortStringsApp);
        StringCount groups[70]={0};
        int groupCount=0;
        for (int i = 1; i < number_of_users; i++)
        {
            if (strcmp(IDs[i],IDs[i-1])!=0){
                groups[groupCount].count++;
                strcpy(groups[groupCount].string,IDs[i-1]);
                groupCount++;
            }
            else
            {
                groups[groupCount].count++;
            }
        }
        strcpy(groups[groupCount].string,IDs[number_of_users-1]);
        groupCount++;
        qsort(groups,groupCount,sizeof(StringCount),sortGroups);
        for(int i=0;i<groupCount;i++)
        {
            printf("%s: %d users\n",groups[i].string,groups[i].count);
        }
    }
    return 0;
}