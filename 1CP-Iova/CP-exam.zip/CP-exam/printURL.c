/*Write a function that prints in lexicographical order of the URLs all the links from an HTML file named on the
command line. An HTML link is of the form <a href="google.com">Click</a> the URL portion is the one enclosed in
quotes. URLs are at most 100 chars long, but arbitrarily many.
I.e.: a possible input is <a href="www.upt.ro">Click1</a> <a href="acsa.upt.ro">Click2</a> which would print
acsa.upt.ro www.upt.ro*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int CompareURL(const void *a, const void *b)
{
    const char *URL1 = *(const char **)a;
    const char *URL2 = *(const char **)b;
    return strcmp(URL1, URL2);
}
void printURL(FILE *inputFile)
{
    char link1[101];
    char link2[101];
    char URL[101];
    char click[10];
    int indexURL = 0;
    char *URL_string[100];
    int number_of_URL = 0;
    while (fscanf(inputFile, "%s %s", link1, link2) == 2)
    {
        int i = 0;
        if (strcmp(link1, "<a") == 0 && strstr(link2, "href=") != 0)
        {
            while (link2[i] != '"')
            {
                i++;
            }
            i++;
            while (link2[i] != '"')
            {
                URL[indexURL++] = link2[i++];
            }
            indexURL = 0;
            strcpy(click, link2 + strlen(link2) - 4);
            if (link2[i] == '"' && link2[i + 1] == '>' && strcmp(click, "</a>") == 0)
            {
                i = i + 2;
                URL_string[number_of_URL] = strdup(URL);
                number_of_URL++;
            }
        }
    }
    qsort(URL_string, number_of_URL, sizeof(char *), CompareURL);
    for (int j = 0; j < number_of_URL; j++)
    {
        printf("%s\n", URL_string[j]);
    }
}
int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Please enter the input file!");
        return -1;
    }
    FILE *inputFile = fopen(argv[1], "r");
    if (inputFile == NULL)
    {
        printf("Please enter the input file!");
        return -1;
    }
    else
    {
        printURL(inputFile);
    }
    return 0;
}