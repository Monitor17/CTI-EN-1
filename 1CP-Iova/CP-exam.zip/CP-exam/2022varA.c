#include<stdio.h>
#include<stdint.h>
int segment(uint64_t n)
{
  int prevBit=n&1;
  int CurrentBit;
  int number_of_Digits=0;
  int no_of_identical_digits=0;
  int new_number=0;
  n=n>>1;
  while(number_of_Digits<64)
    {
      CurrentBit=n&1;
      if(prevBit==CurrentBit)
	{
	  no_of_identical_digits++;
	}
      else
	{
	  no_of_identical_digits++;
	  new_number=new_number*10+no_of_identical_digits%10;
	  no_of_identical_digits=0;
	}
      prevBit=CurrentBit;
      n=n>>1;
      number_of_Digits++;
    }
  new_number=new_number*10+no_of_identical_digits%10;
  return new_number;
}
int main()
{
  printf("%d",segment(172));
  return 0;
}
