/*Implement a function that receives as argument a C-string representing a file path to a Unix system log file (with
the structure described below) and prints the days recorded in the log, in descending order of the number of logged events.
The Unix system log has the following structure:
Month Day Hour:Min:sec hostname A String Representing The Message until end of line
To the right of hostname there is an arbitrary text, until end-of-line which you shall ignore for the purpose of this assignment.*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct
{
    char months[100];
    int days;
    int count;
} event;
int sortDays(const void *a, const void *b)
{
    event *event1 = (event *)a;
    event *event2 = (event *)b;
    if (strcmp(event1->months, event2->months))
    {
        return strcmp(event1->months, event2->months);
    }
    return event1->days - event2->days;
}
int sortEvents(const void *a, const void *b)
{
    event *event1 = (event *)a;
    event *event2 = (event *)b;
    return event2->count - event1->count;
}
int main()
{
    FILE *inputFile = fopen("unixtime.txt", "r");
    if (inputFile == NULL)
    {
        printf("Please enter the input file");
        return -1;
    }
    char random[100];
    int hour, min, sec;
    char hostname[100];
    char string1[100];
    int day;
    char s[100];
    event UnixEvent[100] = {0};
    int eventsNumber = 0;
    while (fgets(s, sizeof(s), inputFile))
    {
        if (sscanf(s, "%3s %2d %d:%d:%d %s %s", string1, &day, &hour, &min, &sec, hostname, random) == 7)
        {
            strcpy(UnixEvent[eventsNumber].months, string1);
            UnixEvent[eventsNumber].days = day;
            eventsNumber++;
        }
    }
    qsort(UnixEvent, eventsNumber, sizeof(event), sortDays);
    int countEvents = 0;
    event EventNotRepeating[100];
    for (int i = 1; i < eventsNumber; i++)
    {
        if (strcmp(UnixEvent[i].months, UnixEvent[i - 1].months) == 0)
        {
            if (UnixEvent[i].days == UnixEvent[i - 1].days)
            {
                EventNotRepeating[countEvents].count++;
            }
            else
            {
                EventNotRepeating[countEvents].count++;
                strcpy(EventNotRepeating[countEvents].months, UnixEvent[i - 1].months);
                EventNotRepeating[countEvents].days = UnixEvent[i - 1].days;
                countEvents++;
            }
        }
        else
        {
            EventNotRepeating[countEvents].count++;
            strcpy(EventNotRepeating[countEvents].months, UnixEvent[i - 1].months);
            EventNotRepeating[countEvents].days = UnixEvent[i - 1].days;
            countEvents++;
        }
    }
    EventNotRepeating[countEvents].count++;
    strcpy(EventNotRepeating[countEvents].months, UnixEvent[eventsNumber - 1].months);
    EventNotRepeating[countEvents].days = UnixEvent[eventsNumber - 1].days;
    countEvents++;
    qsort(EventNotRepeating, countEvents, sizeof(event), sortEvents);
    for (int i = 0; i < countEvents; i++)
    {
        printf("%s %d: %d events\n", EventNotRepeating[i].months, EventNotRepeating[i].days, EventNotRepeating[i].count);
    }
    return 0;
}