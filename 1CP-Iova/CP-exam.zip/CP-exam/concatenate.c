/* Implement a function that receives an array of pointers to C-strings and returns a C-string obtained 
by concatenating the strings from the array which are actually C-floating point numbers (in any C format)*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
int isFloat(const char* s)
{ //-2.3
    for(int i=0;i<strlen(s);i++)
    { 
        if(s[i]=='-' || s[i]=='+' || s[i]=='.')
        {
            if(s[i]=='.' && (isdigit(s[i-1])==0 || isdigit(s[i+1])==0))
            {
                return 0;
            }
            if((s[i]=='-' || s[i]=='+') && (s[i-1]!='e' || isdigit(s[i+1])==0) && i>0)
            {
                return 0;
            }
        }
        else if(isdigit(s[i])==0 && s[i]!='e')
        {
            return 0;
        }
    }
    return 1;
}
char* concatenateFloats(const char** s,int size)
{
    int totalLength=0;
    for(int i=0;i<size;i++)
    {
        totalLength+=strlen(s[i]);
    }
    char* floatcat=(char*)malloc(totalLength+1);
    int j=0;
    for(int i=0;i<size;i++)
    {
        if(isFloat(s[i]))
        {
            int len=strlen(s[i]);
            strcpy(floatcat+j,s[i]);
            j+=len;
        }
    }
    floatcat[j]='\0';
    return floatcat;
    
}
int main(){
    const char *strings[] = {"This", "is", "a", "sample", "string", "with", "3.14","-2.45e+1.47", "and", "-b7.2", "float", "1.e+2", "constants."};
    int size=sizeof(strings)/sizeof(strings[0]);
    char* floatcat=concatenateFloats(strings,size);
    printf("%s",floatcat);
    free(floatcat);
    return 0;
}