/*mplement a function that receives an array of uint8_t, together with its capacity, another array of characters together
with its capacity and builds into the second array a "sentence" consisting of the words made of the printable characters
(as given by isprint),separated by spaces associated to the non-printable chars from the initial array (a sequence of
 non-printable chars will be replaced by a single space)*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdint.h>
void buildSentence(uint8_t inputArray[], size_t capacity_of_input, char outputArray[], size_t capacity_of_output)
{
    size_t output_index = 0;
    int non_printable_found = 0;
    for (size_t i = 0; i < capacity_of_input; i++)
    {
        if (isprint(inputArray[i]))
        {
            outputArray[output_index] = inputArray[i];
            output_index++;
            non_printable_found = 0;
        }
        else
        {
            if (non_printable_found == 0)
            {
                outputArray[output_index] = ' ';
                output_index++;
                non_printable_found = 1;
            }
        }
    }
    if (output_index > capacity_of_output)
    {
        outputArray[capacity_of_output - 1] = '\0';
    }
    else
    {
        outputArray[output_index] = '\0';
    }
    printf("%s", outputArray);
}
int main()
{
    uint8_t inputArray[] = {'H', 'e', 'l', 'l', 'o', '!', 0x01, 0x02, 'W', 'o', 'r', 'l', 'd', 0x03, '1', '2', '3'};
    size_t inputCapacity = sizeof(inputArray) / sizeof(inputArray[0]);
    char outputArray[50];
    size_t outputCapacity = sizeof(outputArray) / sizeof(outputArray[0]);
    buildSentence(inputArray, inputCapacity, outputArray, outputCapacity);
    return 0;
}