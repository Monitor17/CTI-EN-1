/*Big numbers Define a structure type for big numbers, 
represented as arrays (stored as a structure field). 
Write a function that reads two big numbers from a file 
(each one on a different line) and prints in another file their sum, using a dynamically allocated structure.*/
#include<stdio.h>
#include<stdlib.h>
#define MAX_DIGITS 10000
typedef struct {
    int digits[MAX_DIGITS];
    int numDigits;
}big_number;
big_number addBigNumbers(big_number num1,big_number num2)
{
    big_number result;
    result.numDigits=0;
    int carry=0;
    for (int i = 0; i < num1.numDigits || i < num2.numDigits || carry > 0; i++)
     {
        int sum=carry+(i < num1.numDigits ? num1.digits[i] : 0) + (i < num2.numDigits ? num2.digits[i] : 0);
        result.digits[result.numDigits++]=sum%10;
        carry=sum/10;
     }
     return result;
}
int main()
{
    FILE* inputFile=fopen("./input.txt","r");
    FILE* outputFile=fopen("./output.txt","w");
    if(inputFile==NULL || outputFile==NULL)
    {
        printf("Error at reading files");
        return -1;
    }
    big_number created_number1,created_number2;
    created_number1.numDigits=0;
    created_number2.numDigits=0;
    char c;
    while(fscanf(inputFile,"%c",&c)==1 && c!='\n')
        {
            if(c>='0' && c<='9')
            {
                created_number1.digits[created_number1.numDigits++]=c-'0';
            }
        }
     while(fscanf(inputFile,"%c",&c)==1 && c!=EOF)
        {
            if(c>='0' && c<='9')
            {
                created_number2.digits[created_number2.numDigits++]=c-'0';
            }
        }
    for(int i=0;i<created_number1.numDigits/2;i++)
    {
        int aux=created_number1.digits[i];
        created_number1.digits[i]=created_number1.digits[created_number1.numDigits-i-1];
        created_number1.digits[created_number1.numDigits-i-1]=aux;
    }
    for(int i=0;i<created_number2.numDigits/2;i++)
    {
        int aux=created_number2.digits[i];
        created_number2.digits[i]=created_number2.digits[created_number1.numDigits-i-1];
        created_number2.digits[created_number2.numDigits-i-1]=aux;
    }
    fclose(inputFile);

    big_number sum=addBigNumbers(created_number1,created_number2);
    for(int i=sum.numDigits-1;i>=0;i--)
    {
        fprintf(outputFile,"%d",sum.digits[i]);
    }
    fclose(outputFile);
    return 0;
}