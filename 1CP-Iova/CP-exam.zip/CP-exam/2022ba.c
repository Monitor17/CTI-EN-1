#include<stdio.h>
int function()
{
  int c=getchar();
  int currentValue=0;
  int product=1;
  int sum=0;
  while(c!=EOF && c!='\n')
    {
      if(c>='0' && c<='9')
	{
	  while(c>='0' && c<='9')
	    {
	      currentValue=currentValue*10+c-'0';
	      c=getchar();
	    }
	  product=product*currentValue;
	  currentValue=0;
	  continue;
	}
      else if(c=='+')
	{
	  sum=sum+product;
	  product=1;
	}
      else if(c==' ')
	{
	  while(c==' ')
	    {
	      c=getchar();
	    }
	  continue;
	}
      c=getchar();
    }
  sum=sum+product;
  return sum;
}
int main()
{
  int result=function();
  printf("\n\n%d",result);
  return 0;
}
	 
