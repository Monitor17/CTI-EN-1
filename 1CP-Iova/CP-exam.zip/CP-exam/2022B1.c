#include<stdio.h>
#include<ctype.h>
void expression(int c)
{
  int currentValue=0;
  int prevChar;
  int sum=0;
  int expressionValue=1;
  while(c!=EOF)
    {
      if(c>='0' && c<='9')
	{
	  currentValue=currentValue*10+c-'0';
	}
      printf("%c",currentValue);
      c=getchar();
    }
}
int main()
{
  int c=getchar();
  expression(c);
  return 0;
}
       
