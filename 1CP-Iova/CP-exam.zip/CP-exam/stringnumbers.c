/*Implement a function that receives C-styled string and returns a copy of the string where all the digits are replaced with 
their English spelling. I.e. f("Ana are 12 mere si 13.5 pere") should return "Ana are onetwo mere si onethree.five pere"*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char* stringNumberTransform(char* string){
    char *numberString[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
    int count=0;
    for(size_t i=0;string[i];i++)
    {
        if(string[i]>='0' && string[i]<='9')
        {
            count++;
        }
    }
    char* new_string=(char*)malloc((strlen(string)+count*4)*sizeof(char));
    size_t j=0;
    for(size_t i=0;string[i];i++)
    {
        if(string[i]>='0' && string[i]<='9')
        {
            strncpy(new_string+j,numberString[string[i]-'0'],strlen(numberString[string[i]-'0']));
            j+=strlen(numberString[string[i]-'0']);
        }
        else
        {
            new_string[j]=string[i];
            j++;
        }
    }
    return new_string;
}
int main(){
    char* string="Ana are 12 mere si 13.5 pere";
    char* copyString=stringNumberTransform(string);
    printf("%s",copyString);
    return 0;
}