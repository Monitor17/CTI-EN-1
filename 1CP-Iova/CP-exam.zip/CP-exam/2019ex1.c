#include<stdio.h>
#include<ctype.h>
void maximum_number(int c)
{
  int prevChar;
  prevChar=c;
  int currentValue=0;
  int maxValue;
  int ok=1;
  int sign_of_currentValue=1;
  int number_found=0;
  while(c!='\n' && c!=EOF)
    {
      if(c>='0' && c<='9' && isalpha(prevChar)==0)
	{
	  if('-'==prevChar)
	    {
	      sign_of_currentValue=-1;
	    }
	  currentValue=10*currentValue+c-'0';
	  number_found=1;
	}
      else if(' '==c)
	{
	  currentValue=sign_of_currentValue*currentValue;
	  if(1==ok)
	    {
	      maxValue=currentValue;
	      ok=0;
	    }
	  if(currentValue>maxValue)
	    {
	      maxValue=currentValue;
	    }
	  currentValue=0; 
	}
      else if('-'!=c)
	{
	  currentValue=0;
	}
      prevChar=c;
      c=getchar();
    }
  if(0==number_found)
    {
      printf("Invalid input");
    }
  else
    {
      printf("%d",maxValue);
    }
	
}
int main()
{
  int c;
  c=getchar();
  maximum_number(c);
  return 0;
}
     
