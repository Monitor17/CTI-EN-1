/* Write a function double* copyFloats(const char *s, unsigned *n); that returns an array of doubles,
consisting of all the float constants found into string s. Consider floats as being written in any acceptable C format.
Set value pointed by n to the number of elements from the returned array. You shall NOT use strtok!!!*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
double convertFloat(char *s, int *c)
{
    double result = 0.0;
    double fraction = 0.1;
    int sign = 1;
    if (*s == '-')
    {
        sign = -1;
        s++;
        (*c)++;
    }
    else if (*s == '+')
    {
        s++;
        (*c)++;
    }
    while (*s >= '0' && *s <= '9')
    {
        result = result * 10.0 + *s - '0';
        s++;
        (*c)++;
    }
    if (*s == '.')
    {
        s++;
        (*c)++;
        while (*s >= '0' && *s <= '9')
        {
            result += fraction * (*s - '0');
            fraction *= 0.1;
            s++;
            (*c)++;
        }
    }
    if (*s == 'e')
    {
        s++;
        (*c)++;
        if (*s == '+' || *s == '-')
        {
            result *= pow(10, convertFloat(s, c));
        }
    }
    return result * sign;
}
double *copyFloats(const char *s, unsigned *n)
{
    char *input = strdup(s);
    const char *p = s;
    *n = 0;
    while (p[0])
    {
        if (strchr("+-0123456789", p[0]))
        {
            (*n)++;
            while (strchr("+-0123456789", p[0]))
            {
                p++;
            }
        }
        while (strchr("+-0123456789", p[0]) == 0)
        {
            p++;
        }
    }
    double *Floats = (double *)malloc(*n * sizeof(double));
    int c = 0;
    double floatconst;
    unsigned i = 0;
    while (input[0])
    {
        if (strchr("+-0123456789", input[0]))
        {
            floatconst = convertFloat(input, &c);
            input += c;
            Floats[i++] = floatconst;
            c = 0;
        }
        while (strchr("+-0123456789", input[0]) == 0)
        {
            input++;
        }
    }
    *n = i;
    return Floats;
}
int main()
{
    const char *input = "3.44as.4441 1e+2 2e-2 5 -2.95e3333ab -4 ab1.4 ";
    unsigned n;
    double *Floats = copyFloats(input, &n);
    for (unsigned i = 0; i < n; i++)
    {
        printf("%.2lf ", Floats[i]);
    }
}